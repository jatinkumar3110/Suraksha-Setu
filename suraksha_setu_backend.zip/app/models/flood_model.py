import requests
from app.config import settings
from app.schemas import RiskResponse

class FloodModel:
    def __init__(self, settings):
        self.api = settings.lstm_flood_api

    async def predict(self, payload: dict) -> RiskResponse:
        if self.api:
            # call external model
            r = requests.post(self.api, json=payload, timeout=10)
            r.raise_for_status()
            data = r.json()
            return RiskResponse(hazard="flood", risk_score=float(data.get("risk", 0)), message=data.get("message"))
        # placeholder local logic if no external API (simple heuristic)
        rs = min(1.0, (payload.get("rainfall_mm",0) / 200.0) + (payload.get("river_level_m",0) / 20.0))
        msg = "heuristic estimate"
        return RiskResponse(hazard="flood", risk_score=rs, message=msg)
