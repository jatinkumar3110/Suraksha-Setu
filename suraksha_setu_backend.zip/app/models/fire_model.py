import requests
from app.schemas import RiskResponse
from app.config import settings

class FireModel:
    def __init__(self, settings):
        self.api = settings.fire_api

    async def predict(self, payload: dict) -> RiskResponse:
        if self.api:
            r = requests.post(self.api, json=payload, timeout=10)
            r.raise_for_status()
            data = r.json()
            return RiskResponse(hazard="fire", risk_score=float(data.get("risk",0)), message=data.get("message"))
        # fallback heuristic
        t = payload.get("temperature", 25)
        w = payload.get("wind_speed", 0) or 0
        ndvi = payload.get("ndvi", 0.5)
        rs = min(1.0, ((t-25)/30.0) + (w/20.0) + (1 - ndvi))
        return RiskResponse(hazard="fire", risk_score=rs, message="heuristic fallback")
