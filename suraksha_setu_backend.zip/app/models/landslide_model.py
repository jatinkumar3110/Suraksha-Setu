import requests
from app.schemas import RiskResponse
from app.config import settings

class LandslideModel:
    def __init__(self, settings):
        self.api = settings.landslide_api

    async def predict(self, payload: dict) -> RiskResponse:
        if self.api:
            r = requests.post(self.api, json=payload, timeout=10)
            r.raise_for_status()
            data = r.json()
            return RiskResponse(hazard="landslide", risk_score=float(data.get("risk",0)), message=data.get("message"))
        # fallback heuristic
        rain7 = payload.get("rainfall_mm",0)
        slope = payload.get("soil_moisture",0)
        rs = min(1.0, (rain7/300.0) + (slope/100.0))
        return RiskResponse(hazard="landslide", risk_score=rs, message="heuristic fallback")
