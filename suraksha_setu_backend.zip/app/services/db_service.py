from sqlalchemy import create_engine, Column, Integer, String, Float, DateTime, text
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
import datetime
from app.config import settings

Base = declarative_base()

class Alert(Base):
    __tablename__ = 'alerts'
    id = Column(Integer, primary_key=True)
    timestamp = Column(DateTime, default=datetime.datetime.utcnow)
    hazard = Column(String)
    risk_score = Column(Float)
    message = Column(String)

class DBService:
    def __init__(self, settings):
        url = settings.database_url
        self.engine = create_engine(url, echo=False, future=True)
        Base.metadata.create_all(self.engine)
        self.Session = sessionmaker(bind=self.engine)

    def insert_alert(self, risk_response):
        session = self.Session()
        a = Alert(hazard=risk_response.hazard, risk_score=risk_response.risk_score, message=risk_response.message)
        session.add(a)
        session.commit()
        session.close()
        return True
