import openai
from app.config import settings

class OpenAIService:
    def __init__(self, api_key=None):
        api_key = api_key or settings.openai_api_key
        if not api_key:
            raise ValueError("OpenAI API key not set")
        openai.api_key = api_key

    def chat(self, prompt: str, model: str = "gpt-4o-mini"):
        resp = openai.ChatCompletion.create(
            model=model,
            messages=[{"role": "system", "content": "You are Suraksha Setu assistant."},
                      {"role": "user", "content": prompt}],
            max_tokens=300
        )
        return resp.choices[0].message.content
