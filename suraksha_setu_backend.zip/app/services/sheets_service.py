import gspread
from oauth2client.service_account import ServiceAccountCredentials
from app.config import settings
import datetime

class SheetsService:
    def __init__(self, settings):
        creds_json = settings.gsheets_credentials
        if not creds_json:
            raise ValueError("Google Sheets credentials not set")
        scope = ['https://spreadsheets.google.com/feeds','https://www.googleapis.com/auth/drive']
        self.creds = ServiceAccountCredentials.from_json_keyfile_name(creds_json, scope)
        self.client = gspread.authorize(self.creds)

    def log_alert(self, risk_response):
        sheet = self.client.open_by_key(settings.alert_sheet_id).sheet1
        ts = datetime.datetime.utcnow().isoformat()
        row = [ts, risk_response.hazard, risk_response.risk_score, risk_response.message]
        sheet.append_row(row)
        return True
