import smtplib
from email.mime.text import MIMEText
from app.config import settings

class EmailService:
    def __init__(self, settings):
        self.host = settings.smtp_host
        self.port = settings.smtp_port
        self.user = settings.smtp_user
        self.password = settings.smtp_password
        self.from_email = settings.email_from
        if not all([self.host, self.user, self.password, self.from_email]):
            raise ValueError("SMTP credentials or from email not set")

    def send(self, to: str, subject: str, body: str):
        msg = MIMEText(body)
        msg['From'] = self.from_email
        msg['To'] = to
        msg['Subject'] = subject
        s = smtplib.SMTP(self.host, self.port)
        s.starttls()
        s.login(self.user, self.password)
        s.sendmail(self.from_email, [to], msg.as_string())
        s.quit()

    def send_to_list(self, recipients: list, subject: str, body: str):
        for r in recipients:
            self.send(r, subject, body)
        return {"sent_to": recipients}
