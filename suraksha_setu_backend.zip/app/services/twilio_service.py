from twilio.rest import Client
from app.config import settings

class TwilioService:
    def __init__(self, settings):
        self.sid = settings.twilio_account_sid
        self.token = settings.twilio_auth_token
        self.from_num = settings.twilio_from_number
        if not all([self.sid, self.token, self.from_num]):
            raise ValueError("Twilio credentials / From number not set")
        self.client = Client(self.sid, self.token)

    def send_sms(self, to: str, body: str):
        return self.client.messages.create(body=body, from_=self.from_num, to=to)

    def send_bulk_sms(self, to_list, body):
        results = []
        for t in to_list:
            results.append({"to": t, "status": self.send_sms(t.strip(), body).sid})
        return results

    def make_call(self, to: str, twiml_url: str):
        return self.client.calls.create(to=to, from_=self.from_num, url=twiml_url)
