from google.cloud import translate_v2 as translate
from app.config import settings

class TranslateService:
    def __init__(self):
        if not settings.google_credentials:
            raise ValueError("Google credentials not set")
        self.client = translate.Client()

    def translate(self, text: str, target: str):
        res = self.client.translate(text, target_language=target)
        return res['translatedText']
