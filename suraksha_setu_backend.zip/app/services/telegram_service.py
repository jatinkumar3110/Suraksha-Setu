import requests
from app.config import settings

class TelegramService:
    def __init__(self, settings):
        self.token = settings.telegram_bot_token
        self.channel = settings.telegram_channel_id
        if not self.token:
            raise ValueError("Telegram bot token not set")
        self.base = f"https://api.telegram.org/bot{self.token}"

    def send_message(self, channel_id: str, text: str):
        url = f"{self.base}/sendMessage"
        data = {"chat_id": channel_id or self.channel, "text": text}
        r = requests.post(url, json=data, timeout=10)
        r.raise_for_status()
        return r.json()
