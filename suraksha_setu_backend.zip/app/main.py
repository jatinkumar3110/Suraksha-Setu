import os
from fastapi import FastAPI, HTTPException
from app.config import settings
from app.schemas import SensorPayload, RiskResponse
from app.services.openai_service import OpenAIService
from app.services.twilio_service import TwilioService
from app.services.email_service import EmailService
from app.services.telegram_service import TelegramService
from app.services.sheets_service import SheetsService
from app.services.db_service import DBService
from app.models.flood_model import FloodModel
from app.models.landslide_model import LandslideModel
from app.models.fire_model import FireModel

app = FastAPI(title="Suraksha Setu API")


# init services (lazy safe)
try:
    openai = OpenAIService(api_key=settings.openai_api_key)
except Exception as e:
    openai = None
try:
    twilio = TwilioService(settings)
except Exception:
    twilio = None
try:
    emailer = EmailService(settings)
except Exception:
    emailer = None
try:
    telegram = TelegramService(settings)
except Exception:
    telegram = None
try:
    sheets = SheetsService(settings)
except Exception:
    sheets = None
try:
    db = DBService(settings)
except Exception:
    db = None

# models (wrappers that can call local models or remote HTTP endpoints)
flood_model = FloodModel(settings)
landslide_model = LandslideModel(settings)
fire_model = FireModel(settings)

@app.post("/predict/flood", response_model=RiskResponse)
async def predict_flood(payload: SensorPayload):
    try:
        r = await flood_model.predict(payload.dict())
        if sheets:
            try:
                sheets.log_alert(r)
            except Exception:
                pass
        if db:
            try:
                db.insert_alert(r)
            except Exception:
                pass
        return r
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/predict/landslide", response_model=RiskResponse)
async def predict_landslide(payload: SensorPayload):
    try:
        r = await landslide_model.predict(payload.dict())
        if sheets:
            try:
                sheets.log_alert(r)
            except Exception:
                pass
        if db:
            try:
                db.insert_alert(r)
            except Exception:
                pass
        return r
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/predict/fire", response_model=RiskResponse)
async def predict_fire(payload: SensorPayload):
    try:
        r = await fire_model.predict(payload.dict())
        if sheets:
            try:
                sheets.log_alert(r)
            except Exception:
                pass
        if db:
            try:
                db.insert_alert(r)
            except Exception:
                pass
        return r
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/alert/send")
async def send_alert(hazard: str, message: str):
    # sends via Twilio, Email, Telegram
    resp = {}
    if twilio:
        try:
            resp['sms'] = twilio.send_bulk_sms(settings.alert_phone_list.split(','), message)
        except Exception as e:
            resp['sms_error'] = str(e)
    if emailer:
        try:
            resp['email'] = emailer.send_to_list(settings.alert_phone_list.split(','), f"{hazard} Alert", message)
        except Exception as e:
            resp['email_error'] = str(e)
    if telegram:
        try:
            resp['telegram'] = telegram.send_message(settings.telegram_channel_id, message)
        except Exception as e:
            resp['telegram_error'] = str(e)
    return resp
