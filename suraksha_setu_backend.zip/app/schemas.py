from pydantic import BaseModel
from typing import Optional

class SensorPayload(BaseModel):
    timestamp: Optional[str]
    latitude: float
    longitude: float
    rainfall_mm: Optional[float]
    river_level_m: Optional[float]
    humidity: Optional[float]
    temperature: Optional[float]
    soil_moisture: Optional[float]
    ndvi: Optional[float]

class RiskResponse(BaseModel):
    hazard: str
    risk_score: float
    message: Optional[str] = None
