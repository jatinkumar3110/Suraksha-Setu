from pydantic import BaseSettings

class Settings(BaseSettings):
    app_host: str = "0.0.0.0"
    app_port: int = 8000

    openai_api_key: str
    google_credentials: str = None

    twilio_account_sid: str = None
    twilio_auth_token: str = None
    twilio_from_number: str = None

    smtp_host: str = None
    smtp_port: int = 587
    smtp_user: str = None
    smtp_password: str = None
    email_from: str = None

    telegram_bot_token: str = None
    telegram_channel_id: str = None

    gsheets_credentials: str = None
    alert_sheet_id: str = None
    metric_sheet_id: str = None

    database_url: str

    lstm_flood_api: str = None
    xgb_risk_api: str = None
    landslide_api: str = None
    fire_api: str = None

    emergency_phone_list: str = ""
    alert_phone_list: str = ""

    class Config:
        env_file = ".env"

settings = Settings()
