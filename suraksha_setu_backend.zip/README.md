# Suraksha Setu Backend (Prototype)
This repository contains a prototype FastAPI backend for the Suraksha Setu AI-IoT disaster prediction and alerting system.

## Structure
- `app/` : main application code (FastAPI), models, and services
- `infra/` : database initialization SQL
- `.env.example` : example env file (copy to .env and fill secrets)
- `docker-compose.yml` : local docker stack (api + postgres + pgadmin)

## Quick start (local)
1. Copy `.env.example` to `.env` and fill in secrets.
2. `docker-compose up --build`
3. API will be available at `http://localhost:8000`

## Endpoints
- `POST /predict/flood` : Accepts sensor payload JSON, returns flood risk
- `POST /predict/landslide` : Landslide risk
- `POST /predict/fire` : Forest fire risk
- `POST /alert/send` : send alerts via configured channels
